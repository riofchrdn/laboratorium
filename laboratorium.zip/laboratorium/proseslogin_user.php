<?php
session_start();
include 'koneksi.php';
$username = $_POST['username'];
$password = $_POST['password'];
$data = mysqli_query($conn,"select * from user_login where username='$username' and password='$password'");
$cek = mysqli_num_rows($data);
 
if($cek > 0){
	$_SESSION['username'] = $username;
	$_SESSION['status'] = "login";
	header("location:index_user.php");
}else{
	$_SESSION['username'] = $username;
	$_SESSION['status'] = "gagal";
	header("location:login_user.php?pesan=gagal");
}
?>