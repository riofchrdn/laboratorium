<?php
//koneksi
include '../koneksi.php';

// memanggil library FPDF
require('fpdf.php');

$no=1;
$id = $_GET['id'];
$query = mysqli_query($conn, "select * from rapidtest WHERE id = '$id'");
// while ($row = mysqli_fetch_array($query)){

class labPDF extends FPDF{
    function header(){
      $this->SetFont('Arial','B',14);
      $this->Cell(276,5,'KLINIK MUTIARA 1',0,0,'C');
      $this->Ln();
      $this->SetFont('Times','',12);
      $this->Cell(276,10,'Alamat',0,0,'C');
      $this->Ln(20);
    }
    function footer(){
      $this->SetY(-15);
      $this->SetFont('Arial','',8);
      // $this->Cell(0,10,'Page'.$this->Directed,0,0,'C');
    }
    function headerTable(){
      $this->SetFont('Times','B',12);
      $this->Cell(20,10,'ID',1,0,'C');
      $this->Cell(20,10,'Nomor MCU',1,0,'C');
      $this->Cell(20,10,'Nama Pasien',1,0,'C');
      $this->Cell(20,10,'Tanggal Lahir',1,0,'C');
      $this->Cell(20,10,'Tanggal Test',1,0,'C');
      $this->Cell(20,10,'Alamat',1,0,'C');
      $this->Cell(20,10,'Dokter Pengirim',1,0,'C');
      $this->Cell(20,10,'Hasil IGG',1,0,'C');
      $this->Cell(20,10,'Rujukan IGG',1,0,'C');
      $this->Cell(20,10,'Hasil IGM',1,0,'C');
      $this->Cell(20,10,'Rujukan IGM',1,0,'C');
      $this->Cell(20,10,'Satuan',1,0,'C');
      $this->Cell(20,10,'Keterangan',1,0,'C');
      $this->Cell(20,10,'Catatan',1,0,'C');
    }
  }
// }

$pdf = new labPDF();
$pdf->AddPage('L', 'A5', 0);

//nama file
while ($row = mysqli_fetch_array($query)){
$pdf->Output();
}
?>
