<?php
include "koneksi.php";

if (isset($_POST['simpan'])) {
	
	$nama_pasien		= $_POST['nama_pasien'];
	$tgl_lahir			= $_POST['tgl_lahir'];
	$tgl_test			= $_POST['tgl_test'];
	$kelas				= $_POST['kelas'];
	$alamat				= $_POST['alamat'];
	


	$simpan = "INSERT INTO rapidtest(nama_pasien,tgl_lahir,tgl_test,kelas,alamat)VALUES('$nama_pasien','$tgl_lahir','$tgl_test','$kelas','$alamat')";

	$result = mysqli_query($conn,$simpan);

	if ($result) {
		echo "<script>alert('Data Telah Berhasil di Simpan');window.location='index.php'</script>";
	}
}
?>
