<!DOCTYPE html>
<html lang="en">
<head>
	<title>HASIL PEMERIKSAAN RAPID TEST</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
		<div class="container">
		  <h2 class='title-form'>HASIL PEMERIKSAAN RAPID TEST</h2>
		  <a class="btn btn-info btn-view-class" href="tampil.php"><i class="fa fa-search" ></i>  </a>

		  <form class="form-horizontal" action="aksi.php" method="POST">
		    <div class="form-group">
		      <label class="control-label col-sm-2">Nama Pasien</label>
		      <div class="col-sm-10">
		        <input type="text" class="form-control" name="nama_pasien" placeholder="Nama Pasien">
		      </div>
		    </div>
		   <div class="form-group">
		      <label class="control-label col-sm-2">Tanggal Lahir</label>
		      <div class="col-sm-10">
		        <input type="date" class="form-control" name="tgl_lahir">
		      </div>
		    </div>

		    <div class="form-group">
		      <label class="control-label col-sm-2">Tanggal Test</label>
		      <div class="col-sm-10">
		        <input type="date" class="form-control" name="tgl_test">
		      </div>
		    </div>
	

	   		<div class="form-group">
		      <label class="control-label col-sm-2">Alamat</label>
		      <div class="col-sm-10">
		        <input type="text" class="form-control" name="alamat" placeholder="Alamat">
		      </div>
		    </div>
	

	   		<div class="form-group">
		      <label class="control-label col-sm-2">Kelas</label>
		      <div class="col-sm-10">
		      			<label class="radio-inline">
		         <input type="radio" name="kelas" value="1 MTS  SMP" checked>1 MTS / SMP
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="kelas" value="2 MTS  SMP" checked>2 MTS / SMP
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="kelas" value="3 MTS  SMP" checked>3 MTS / SMP
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="kelas" value="1 MA  SMA" checked>1 MA / SMA
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="kelas" value="2 MA  SMA" checked>2 MA / SMA
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="kelas" value="3 MA  SMA" checked>3 MA / SMA
		    </label>
		</div>
	</div>

		    <div class="form-group">        
		      <div class="col-sm-offset-2 col-sm-10">
		        <button type="submit" name="simpan" class="btn btn-success">Submit</button>
				<button type="reset" name="reset" class="btn btn-danger">Hapus</button>
				<button type="reset" name="logout" class="btn btn-danger">Logout</button>
		      </div>
		    </div>
		  </form>
		</div>
		      </div>
		   	

</body>
</html>