<!DOCTYPE html>
<html>
<head>
	<title>HASIL PEMERIKSAAN RAPID TEST</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="style.css">

</head>
<body>
		<div class="container">
		  <h2 class='title-form'>HASIL PEMERIKSAAN RAPID TEST</h2>
		  <a class="btn btn-info btn-view-class" href="tampil_admin.php"><i class="fa fa-search" ></i>  </a>

		  <form class="form-horizontal" action="aksi.php" method="POST">
		    <div class="form-group">
		      <label class="control-label col-sm-2">Nomor MCU</label>
		      <div class="col-sm-10">
		        <input type="number" class="form-control" name="nomor_mcu" placeholder="Nomor MCU">
		      </div>
		    </div>
		   <div class="form-group">
		      <label class="control-label col-sm-2">Nama Pasien</label>
		      <div class="col-sm-10">
		        <input type="text" class="form-control" name="nama_pasien" placeholder="Nama Pasien">
		      </div>
		    </div>

		    <div class="form-group">
		      <label class="control-label col-sm-2">Tanggal Lahir</label>
		      <div class="col-sm-10">
		        <input type="date" class="form-control" name="tgl_lahir">
		      </div>
		    </div>
	

	   		<div class="form-group">
		      <label class="control-label col-sm-2">Tanggal Test</label>
		      <div class="col-sm-10">
		        <input type="date" class="form-control" name="tgl_test">
		      </div>
		    </div>
	

	   		<div class="form-group">
		      <label class="control-label col-sm-2">Alamat</label>
		      <div class="col-sm-10">
		        <input type="text" class="form-control" name="alamat" placeholder="Alamat">
		      </div>
		    </div>

		    <div class="form-group">
		      <label class="control-label col-sm-2">Kelas</label>
		      <div class="col-sm-10">
		      			<label class="radio-inline">
		         <input type="radio" name="kelas" value="1 MTS  SMP" checked>1 MTS / SMP
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="kelas" value="2 MTS  SMP" checked>2 MTS / SMP
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="kelas" value="3 MTS  SMP" checked>3 MTS / SMP
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="kelas" value="1 MA  SMA" checked>1 MA / SMA
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="kelas" value="2 MA  SMA" checked>2 MA / SMA
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="kelas" value="3 MA  SMA" checked>3 MA / SMA
		    </label>
		</div>
	</div>

		    <div class="form-group">
		      <label class="control-label col-sm-2">Dokter Pengirim</label>
		      <div class="col-sm-10">
		        <input type="text" class="form-control" name="dokter_pengirim" placeholder="Dokter Pengirim">
		      </div>
		    </div>

		    <div class="form-group">
		      <label class="control-label col-sm-2">Hasil Pemeriksaan (IGG COV-2)</label>
		      <div class="col-sm-10">
		      			<label class="radio-inline">
		         <input type="radio" name="hasil_igg" value="Reaktif" checked>Reaktif
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="hasil_igg" value="Non Reaktif" checked>Non Reaktif
		    </label>
		      </div>
		    </div>

		     <div class="form-group">
		      <label class="control-label col-sm-2">Hasil Pemeriksaan (IGM COV-2)</label>
		      <div class="col-sm-10">
		      			<label class="radio-inline">
		         <input type="radio" name="hasil_igm" value="Reaktif" checked>Reaktif
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="hasil_igm" value="Non Reaktif" checked>Non Reaktif
		    </label>
		      </div>
		    </div>	


		     <div class="form-group">
		      <label class="control-label col-sm-2 ">Rujukan ( IGG COV-2)</label>
		      <div class="col-sm-10">
		     	         <label class="radio-inline">
		      <input type="radio" name="rujukan_igg" value="Reaktif" checked>Reaktif
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="rujukan_igg" value="Non Reaktif" checked>Non Reaktif
		    </label>	
		      </div>
		    </div>

		    <div class="form-group">
		      <label class="control-label col-sm-2 ">Rujukan ( IGM COV-2)</label>
		      <div class="col-sm-10">
		     	         <label class="radio-inline">
		      <input type="radio" name="rujukan_igm" value="Reaktif" checked>Reaktif
		    </label>
		    <label class="radio-inline">
		   	  <input type="radio"  name="rujukan_igm" value="Non Reaktif" checked>Non Reaktif
		    </label>	
		      </div>
		    </div>

			<div class="form-group">
		      <label class="control-label col-sm-2">Satuan</label>
		      <div class="col-sm-10">
		        <input type="text" class="form-control" name="satuan" placeholder="Satuan">
		      </div>
		    </div>


		    <div class="form-group">
		      <label class="control-label col-sm-2">Keterangan</label>
		      <div class="col-sm-10">
		        <input type="text" class="form-control" name="keterangan" placeholder="Keterangan">
		      </div>
		    </div>

		     <div class="form-group">
		      <label class="control-label col-sm-2">Catatan</label>
		      <div class="col-sm-10">
		        <input type="text" class="form-control" name="catatan" placeholder="Catatan">
		      </div>
		    </div>

		     <div class="form-group">
		      <label class="control-label col-sm-2">Spesimen</label>
		      <div class="col-sm-10">
		        <input type="text" class="form-control" name="spesimen" placeholder="Spesimen">
		      </div>
		    </div>

		     <div class="form-group">
		      <label class="control-label col-sm-2">Jam Pengambilan Spesimen</label>
		      <div class="col-sm-10">
		        <input type="time" class="form-control" name="jam_spesimen" placeholder="Jam Pengambilan">
		      </div>
		    </div>

	
		    <div class="form-group">        
		      <div class="col-sm-offset-2 col-sm-10">
		        <button type="submit" name="simpan" class="btn btn-success">Submit</button>
		            <button type="reset" name="reset" class="btn btn-danger">Hapus</button>
		      </div>
		    </div>
		  </form>
		</div>
</body>
</html>