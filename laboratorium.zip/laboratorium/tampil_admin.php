<html>
<head>

    <link rel="stylesheet" type="text/css" href="style.css">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<?php
include "koneksi.php";
$query = mysqli_query($conn, 'SELECT * FROM rapidtest ORDER BY id ASC');
?>

<form action="" class="form-inline" method="POST"><center>
    <!-- <input type="text" class="form-control" name="query" placeholder="Cari Data" />
    <input type="submit" name="Search" placeholder="Cari Data" /></center> -->

<!--        <div class="form-group">
          <div class="col-sm-10">



          </div>
        </div> -->

            <div class="form-group">
               <input type="text" class="form-control" name="query" placeholder="Cari Data">
            <input type="submit" name="Search" class="btn btn-primary" placeholder="Cari Data" />
            </div>

</form>

<a href="resume_all.php" class="btn btn-info btn-center" > Print All </a>


<br>
<table class="table table-hover">
    <tr>
        <th>No</th>
        <th>Nomor MCU</th>
        <th>Nama Pasien</th>
        <th>Kelas</th>
        <th>Tanggal Lahir</th>
        <th>Tanggal Test</th>
        <th>Alamat</th>
        <th>Dokter Pengirim</th>
        <th>Hasil IGG</th>
        <th>Hasil IGM</th>
        <th>Rujukan IGG</th>
        <th>Rujukan IGM</th>
        <th>Satuan</th>
        <th>Keterangan</th>
        <th>Catatan</th>
        <th>Spesimen</th>
        <th>Jam Pengambilan</th>
        <th>Aksi</th>
    </tr>

    <?php
        if(mysqli_num_rows($query)>0){
          $no=1;

          while($row = mysqli_fetch_assoc($query)){
    ?>
    <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $row['nomor_mcu']; ?></td>
        <td><?php echo $row['nama_pasien']; ?></td>
        <td><?php echo $row['kelas']; ?></td>
        <td><?php echo $row['tgl_lahir']; ?></td>
        <td><?php echo $row['tgl_test']; ?></td>
        <td><?php echo $row['alamat']; ?></td>
        <td><?php echo $row['dokter_pengirim']; ?></td>
        <td><?php echo $row['hasil_igg']; ?></td>
        <td><?php echo $row['hasil_igm']; ?></td>
        <td><?php echo $row['rujukan_igg']; ?></td>
        <td><?php echo $row['rujukan_igm']; ?></td>
        <td><?php echo $row['satuan']; ?></td>
        <td><?php echo $row['keterangan']; ?></td>
        <td><?php echo $row['catatan']; ?></td>
        <td><?php echo $row['spesimen']; ?></td>
        <td><?php echo $row['jam_spesimen']; ?></td>



        <td>

        <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-primary"><i class="fa fa-pencil"></i> </a>
        <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"><i class="fa fa-trash"></i> </a>
        <a href="libr/resume.php?id=<?php echo $row['id']; ?>" class="btn btn-success"><i class="fa fa-print"></i> </a>


        </td>
    </tr>
    <?php
        }
    }
    ?>
</table>


<a href="index_admin.php" class="btn btn-primary back-main-menu" > <i class="fa fa-caret-left" ></i> Back</a>

</body>
</html>