<?php 
include 'koneksi.php';
if(isset($_POST['update'])){
	
	$nomor_mcu			= $_POST['nomor_mcu'];
	$nama_pasien		= $_POST['nama_pasien'];
	$kelas				= $_POST['kelas'];
	$tgl_lahir			= $_POST['tgl_lahir'];
	$tgl_test			= $_POST['tgl_test'];
	$alamat				= $_POST['alamat'];
	$dokter_pengirim	= $_POST['dokter_pengirim'];
	$hasil_igg			= $_POST['hasil_igg'];
	$rujukan_igg		= $_POST['rujukan_igg'];
	$satuan				= $_POST['satuan'];
	$keterangan			= $_POST['keterangan'];
	$hasil_igm			= $_POST['hasil_igm'];
	$rujukan_igm		= $_POST['rujukan_igm'];
	$catatan			= $_POST['catatan'];
	$spesimen			= $_POST['spesimen'];
	$jam_spesimen		= $_POST['jam_spesimen'];

$query = "UPDATE rapidtest SET nomor_mcu='$nomor_mcu', nama_pasien='$nama_pasien', kelas='$kelas', tgl_lahir='$tgl_lahir', tgl_test='$tgl_test', alamat='$alamat', dokter_pengirim='$dokter_pengirim', hasil_igg='$hasil_igg', rujukan_igg='$rujukan_igg', satuan='$satuan', keterangan='$keterangan', hasil_igm='$hasil_igm', rujukan_igm='$rujukan_igm', catatan='$catatan', spesimen='$spesimen', jam_spesimen='$jam_spesimen'  WHERE id='$id'";

$result = mysqli_query($conn, $query);


header("location:tampil_admin.php");

 
}
?>