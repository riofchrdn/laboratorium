<?php
include "koneksi.php";

$id = $_GET['id'];
$qry_delete = "DELETE FROM rapidtest WHERE id = '$id'";
$exe_qry_delete = mysqli_query($conn, $qry_delete);

if($exe_qry_delete){
  echo ("
  <script LANGUAGE='JavaScript'>
    window.alert('Succesfully Deleted');
    window.location.href='tampil_admin.php';
  </script>");
}
?>