<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "lab";

$conn = new mysqli($hostname,$username,$password,$database);

if ($conn->connect_error) {
   // jika terjadi error, matikan proses dengan die() atau exit();
	die('Maaf koneksi gagal: '. $conn->connect_error);
}

?>